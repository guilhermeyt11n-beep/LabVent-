(() => {
  'use strict';
  const SUPABASE_URL = 'https://lvsxipzgavzndogmyauy.supabase.co';
  const SUPABASE_KEY = 'sb_publishable_Zfl-r-oR9iRmr4kggag_9w_lzDP2MJ0';
  const $ = id => document.getElementById(id);
  const state = { client: null, mode: 'login', busy: false, user: null, appLoaded: false, syncTimer: null, syncSnapshot: null, syncChain: Promise.resolve() };
  const localKey = 'labvent_v3';
  function message(id, text, kind='auth-info') { const el=$(id); el.className=kind; el.textContent=text; }
  function clearMessage(id) { const el=$(id); el.className=''; el.textContent=''; }
  function errorText(e) { const s=String(e?.message||e||'Erro desconhecido'); if(/invalid login credentials/i.test(s))return 'E-mail ou senha incorretos.'; if(/email not confirmed/i.test(s))return 'Confirme seu e-mail pelo link enviado antes de entrar.'; if(/user already registered/i.test(s))return 'Este e-mail já está cadastrado. Tente entrar.'; if(/failed to fetch|networkerror|fetch failed/i.test(s))return 'Não foi possível conectar ao Supabase. Verifique a internet e tente novamente.'; return s; }
  function mode(m) { state.mode=m; $('authTitle').textContent=m==='login'?'Bem-vindo de volta':'Crie sua conta'; $('authSubtitle').textContent=m==='login'?'Entre na sua conta para continuar.':'Preencha os dados para começar.'; $('authNameWrap').classList.toggle('auth-hide',m!=='signup'); $('forgotPassword').classList.toggle('auth-hide',m!=='login'); $('authPassword').autocomplete=m==='login'?'current-password':'new-password'; document.querySelectorAll('[data-auth-mode]').forEach(b=>b.classList.toggle('active',b.dataset.authMode===m)); $('authSubmit').textContent=m==='login'?'Entrar':'Criar conta'; clearMessage('authMessage'); }
  function busy(on,label) { state.busy=on; const b=$('authSubmit'); b.disabled=on; b.textContent=on?label:(state.mode==='login'?'Entrar':'Criar conta'); }
  async function remoteLoad(user) {
    const [projectsRes,favsRes,prefsRes] = await Promise.all([
      state.client.from('user_projects').select('title,project_data,created_at').eq('user_id',user.id).order('created_at',{ascending:false}),
      state.client.from('user_favorites').select('item_key,metadata,created_at').eq('user_id',user.id).order('created_at',{ascending:false}),
      state.client.from('user_preferences').select('preferences').eq('user_id',user.id).maybeSingle()
    ]);
    const errors=[projectsRes.error,favsRes.error,prefsRes.error].filter(Boolean); if(errors.length) throw errors[0];
    const remoteHasData=projectsRes.data.length||favsRes.data.length||prefsRes.data?.preferences?.labvent_state;
    let current={}; try{current=JSON.parse(localStorage.getItem(localKey)||'{}')}catch{}
    if(!remoteHasData && ((current.projects||[]).length||(current.favorites||[]).length)) {
      await remoteSave(user,current); return current;
    }
    if(prefsRes.data?.preferences?.labvent_state) return prefsRes.data.preferences.labvent_state;
    return {
      projects: projectsRes.data.map(row=>row.project_data && Object.keys(row.project_data).length ? row.project_data : {id:row.created_at,name:row.title,content:'',type:'Projeto',createdAt:Date.parse(row.created_at)||Date.now()}),
      favorites: favsRes.data.map(row=>Object.assign({},row.metadata||{},{id:row.item_key,createdAt:Date.parse(row.created_at)||Date.now()})),
      prefs: current.prefs || {theme:'light',animations:true,accent:'turquoise',niche:'',platform:'YouTube',format:'Lista prática',tone:'Conversacional',duration:'5',language:'Português (Brasil)',autosave:true}, dark:false
    };
  }
  async function remoteSave(user, data) {
    const prefs = {labvent_state:data, theme:data.prefs?.theme||'light'};
    const p = await state.client.from('user_preferences').upsert({user_id:user.id,preferences:prefs,updated_at:new Date().toISOString()},{onConflict:'user_id'}); if(p.error) throw p.error;
    const delP=await state.client.from('user_projects').delete().eq('user_id',user.id); if(delP.error) throw delP.error;
    const projects=(data.projects||[]).map(item=>({user_id:user.id,title:String(item.name||'Projeto').slice(0,160),project_data:item}));
    if(projects.length){const ins=await state.client.from('user_projects').insert(projects);if(ins.error)throw ins.error;}
    const delF=await state.client.from('user_favorites').delete().eq('user_id',user.id); if(delF.error) throw delF.error;
    const favorites=(data.favorites||[]).map(item=>({user_id:user.id,item_type:'labvent_item',item_key:String(item.id||`${item.title}-${item.createdAt}`).slice(0,200),metadata:item}));
    if(favorites.length){const ins=await state.client.from('user_favorites').insert(favorites);if(ins.error)throw ins.error;}
  }
  window.LabVentSync={saveState(data){if(!state.user)return;state.syncSnapshot=JSON.parse(JSON.stringify(data));clearTimeout(state.syncTimer);state.syncTimer=setTimeout(()=>{const snapshot=state.syncSnapshot;state.syncChain=state.syncChain.then(()=>remoteSave(state.user,snapshot)).catch(e=>{console.error('LabVent sync:',e);if(document.body.classList.contains('authenticated'))message('authMessage','Seus dados ficaram salvos neste navegador, mas a sincronização falhou: '+errorText(e),'auth-error');});},650);},async flush(){clearTimeout(state.syncTimer);if(state.user&&state.syncSnapshot){const snapshot=state.syncSnapshot;state.syncSnapshot=null;state.syncChain=state.syncChain.then(()=>remoteSave(state.user,snapshot));}await state.syncChain;}};
  async function enterApp(user) {
    state.user=user; $('authForms').classList.add('auth-hide'); $('authRecovery').classList.add('auth-hide'); $('authLoading').classList.remove('auth-hide');
    try {
      const data=await remoteLoad(user); localStorage.setItem(localKey,JSON.stringify(data));
      document.body.classList.add('authenticated'); $('authGate').classList.add('auth-hide');
      $('userEmail').textContent=user.email||'Conta ativa'; $('userName').textContent=user.user_metadata?.full_name||'Criador'; $('userAvatar').textContent=($('userName').textContent.trim()[0]||'C').toUpperCase();
      if(!state.appLoaded){state.appLoaded=true;const script=document.createElement('script');script.src='app.js';script.onerror=()=>{document.body.classList.remove('authenticated');$('authGate').classList.remove('auth-hide');message('authMessage','Não foi possível carregar o painel. Recarregue a página.','auth-error');};document.body.appendChild(script);}
    } catch(e) { console.error('Load account data:',e); $('authLoading').classList.add('auth-hide'); $('authForms').classList.remove('auth-hide'); message('authMessage','Não foi possível carregar seus dados. '+errorText(e),'auth-error'); }
  }
  document.querySelectorAll('[data-auth-mode]').forEach(b=>b.addEventListener('click',()=>mode(b.dataset.authMode)));
  $('authForm').addEventListener('submit',async e=>{e.preventDefault();if(state.busy)return;clearMessage('authMessage');if(!state.client){message('authMessage','A biblioteca de autenticação não carregou. Recarregue a página.','auth-error');return;}const email=$('authEmail').value.trim(),password=$('authPassword').value;if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){message('authMessage','Digite um e-mail válido.','auth-error');return;}if(password.length<6){message('authMessage','A senha precisa ter pelo menos 6 caracteres.','auth-error');return;}if(state.mode==='signup'&&!$('authName').value.trim()){message('authMessage','Informe seu nome.','auth-error');return;}busy(true,state.mode==='login'?'Entrando…':'Criando conta…');try{let result;if(state.mode==='login')result=await state.client.auth.signInWithPassword({email,password});else result=await state.client.auth.signUp({email,password,options:{data:{full_name:$('authName').value.trim()},emailRedirectTo:location.href.split('#')[0]}});if(result.error)throw result.error;if(state.mode==='signup'&&result.data.user&&!result.data.session){message('authMessage','Conta criada. Confirme o e-mail recebido e depois entre.','auth-success');}else if(result.data.session){await enterApp(result.data.user);}else{message('authMessage','Não há sessão ativa. Confira o e-mail e tente entrar.','auth-info');}}catch(err){console.error('Auth error:',err);message('authMessage',errorText(err),'auth-error');}finally{busy(false);}});
  $('forgotPassword').addEventListener('click',()=>{$('authForms').classList.add('auth-hide');$('authRecovery').classList.remove('auth-hide');$('recoveryEmail').value=$('authEmail').value.trim();clearMessage('recoveryMessage');});
  $('recoveryBack').addEventListener('click',()=>{$('authRecovery').classList.add('auth-hide');$('authForms').classList.remove('auth-hide');});
  $('recoveryForm').addEventListener('submit',async e=>{e.preventDefault();const b=$('recoverySubmit');b.disabled=true;b.textContent='Enviando…';try{const {error}=await state.client.auth.resetPasswordForEmail($('recoveryEmail').value.trim(),{redirectTo:location.href.split('#')[0]});if(error)throw error;message('recoveryMessage','Se o endereço estiver cadastrado, enviaremos um link de recuperação. Confira também o spam.','auth-success');}catch(err){message('recoveryMessage',errorText(err),'auth-error');}finally{b.disabled=false;b.textContent='Enviar link';}});
  $('signOut').addEventListener('click',async()=>{const b=$('signOut');b.disabled=true;b.textContent='Saindo…';try{await window.LabVentSync.flush?.();const {error}=await state.client.auth.signOut();if(error)throw error;location.reload();}catch(e){message('authMessage','Não foi possível sair: '+errorText(e),'auth-error');b.disabled=false;b.textContent='Sair';}});
  async function start(){if(!window.supabase?.createClient){message('authMessage','Não foi possível carregar o serviço de autenticação. Confira sua internet e recarregue.','auth-error');return;}try{state.client=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});const {data,error}=await state.client.auth.getSession();if(error)throw error;if(data.session)await enterApp(data.session.user);else document.body.classList.remove('authenticated');state.client.auth.onAuthStateChange((event,session)=>{if(event==='SIGNED_OUT'){document.body.classList.remove('authenticated');location.reload();}});}catch(e){console.error(e);message('authMessage',errorText(e),'auth-error');}}
  start();
})();
