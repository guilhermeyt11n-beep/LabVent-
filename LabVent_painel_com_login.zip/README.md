# LabVent — painel com autenticação

## Publicação de teste no Netlify Drop

Envie **os quatro arquivos juntos, na raiz da pasta**:
- `index.html`
- `styles.css`
- `app.js`
- `auth.js`

Não envie somente o `index.html`: o painel e o estilo dependem dos outros arquivos. O `index.html` é o arquivo de entrada exigido pelo Netlify.

## O que esta versão faz

- Login, cadastro, recuperação de senha e logout via Supabase Auth.
- O painel só é carregado depois de uma sessão válida.
- Carrega projetos, favoritos e preferências do Supabase e tenta sincronizar alterações entre dispositivos.
- Mantém o layout e as ferramentas da versão LabVent base.

## Segurança

A página usa apenas a chave pública `publishable` do Supabase. Nunca adicione uma chave `service_role` ou chave secreta ao frontend. As tabelas `profiles`, `user_projects`, `user_favorites` e `user_preferences` devem manter RLS habilitado e políticas que limitem os registros ao `auth.uid()`.

## Nota de integração

Esta versão usa `user_preferences.preferences.labvent_state` como snapshot do estado da interface, além de espelhar projetos e favoritos nas tabelas dedicadas. Teste cadastro, login, criação/remoção de projeto e favorito e login em outro dispositivo antes de substituir o site principal.
